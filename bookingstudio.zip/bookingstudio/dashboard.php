<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit;
}

$nama = $_SESSION['nama'];
?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard Booking Studio</title>
</head>
<body>
  <h2>Hai, <?= $nama ?>! 👋</h2>
  <ul>
    <li><a href="cek_jadwal.php">🔍 Cek Jadwal & Booking Studio</a></li>
    <li><a href="riwayat_booking.php">📋 Lihat Semua Booking</a></li> <!-- opsional -->
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</body>
</html>
